package com.micro.dto;

import org.springframework.stereotype.Component;

@Component
public class FacetsDto {

}
